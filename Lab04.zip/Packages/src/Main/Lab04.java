package Main;

import add.Add;
import divide.Divide;
import multiply.Multiply;
import subtract.Subtract;
import modulo.Modulo;

public class Lab04 {

   public static void main(String[] args) {
	   System.out.println("Student name: Mohammad Taufique Imrose");
       Add number = new Add(5, 3);
       System.out.println("Add method:");
       System.out.println("------------");
       System.out.println(number.toString());
       number.changeVals(4, 4);
       System.out.println(number.toString());

       Subtract sub = new Subtract(5, 3);
       System.out.println("Subtract method:");
       System.out.println("-----------------");
       System.out.println(sub.toString());
       number.changeVals(4, 4);
       System.out.println(sub.toString());

       Multiply mult = new Multiply(5, 3);
       System.out.println("Multiply method:");
       System.out.println("-----------------");
       System.out.println(mult.toString());
       number.changeVals(4, 4);
       System.out.println(mult.toString());

       Divide div = new Divide(5, 3);
       System.out.println("Divide method:");
       System.out.println("---------------");
       System.out.println(div.toString());
       number.changeVals(4, 4);
       System.out.println(div.toString());

       Modulo mod = new Modulo(5, 3);
       System.out.println("Modulo method:");
       System.out.println("---------------");
       System.out.println(mod.toString());
       mod.changeVals(4, 4);
       System.out.println(mod.toString());

   }

}